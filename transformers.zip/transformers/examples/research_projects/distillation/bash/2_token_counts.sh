python /home/CE/musaeed/transformers/examples/research_projects/distillation/scripts/binarized_data.py \
    --file_path /content/arabic.txt \
    --tokenizer_type bert \
    --tokenizer_name asafaya/bert-large-arabic \
    --dump_file /content/data/binarized_text