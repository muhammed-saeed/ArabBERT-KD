python /home/CE/musaeed/transformers/examples/research_projects/distillation/scripts/token_counts.py \
    --data_file /content/data/binarized_text.pickle \
    --token_counts_dump /content/data/token_counts.pickle \
    --vocab_size 32000